import java.util.Collection;

public class Barco {
    private int MIN_TRIPULANTES = 3;
    private int numero;

    private Posicion ubicacion;

    private Collection<Marino> marinos;
    
    public void muevase(int deltaLongitud,int deltaLatitud){
        
    }
    
}
